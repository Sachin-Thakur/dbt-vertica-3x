


select * from {{ ref('data_except_a') }} {{ except() }} select * from {{ ref('data_except_b') }}
