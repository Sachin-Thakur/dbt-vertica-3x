




select

    {{ right('string_text', 'length_expression') }}
  

from {{ ref('data_right') }}