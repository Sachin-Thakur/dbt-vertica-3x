








-- with data as (

    -- select * from {{ ref('data_concat') }}

-- )

select
   {{ concat(['input_1', 'input_2']) }}
    output as expected

from data_concat