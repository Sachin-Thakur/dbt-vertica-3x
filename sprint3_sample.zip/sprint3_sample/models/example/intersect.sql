


select * from {{ ref('data_intersect_a') }} {{ intersect() }} select * from {{ ref('data_intersect_b') }}