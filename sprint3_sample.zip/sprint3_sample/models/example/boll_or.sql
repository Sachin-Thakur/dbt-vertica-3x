


    select
        key,
        {{ bool_or('val1 = val2') }} 
    from  {{ ref('data_bool_or') }}
    group by key